/*package ListadoDeHogaresDeTransito;

public class EjemploDeUso {

    public static void main(String[] args ){
        ServicioDeHogaresDeTransito servicioDeHogaresDeTransito =
    }
}*/
/*encontre mascota perdida boyon*/
