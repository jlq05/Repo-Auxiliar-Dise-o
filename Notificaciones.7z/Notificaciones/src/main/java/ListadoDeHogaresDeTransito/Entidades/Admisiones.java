package ListadoDeHogaresDeTransito.Entidades;

public class Admisiones {
    public Boolean perros;
    public Boolean gatos;
}
