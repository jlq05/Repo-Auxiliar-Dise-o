package ListadoDeHogaresDeTransito.Entidades;

public class Ubicacion {
    public String direccion;
    public Float lat;
    public Float longitud;
}
