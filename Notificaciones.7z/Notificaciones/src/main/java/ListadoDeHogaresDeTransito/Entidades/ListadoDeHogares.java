package ListadoDeHogaresDeTransito.Entidades;



import java.util.List;

public class ListadoDeHogares {
    public Integer total;
    public Integer offset;
    private List<Hogares> hogares;

}

